import React from 'react';

function Home() {
    return (
        <div>
            fwlflf
        </div>
    );
}

export default Home;